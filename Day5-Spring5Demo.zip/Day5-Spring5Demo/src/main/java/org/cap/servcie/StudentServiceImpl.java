package org.cap.servcie;

import java.util.List;

import org.cap.dao.StudentDao;
import org.cap.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("studentService")
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentDao studentDao;
	@Override
	public List<Student> getStudents() {
		// TODO Auto-generated method stub
		return studentDao.getStudents();
	}
	@Override
	public Student findStudent(Integer studentId) {
		return studentDao.findStudent(studentId);
	}
	@Override
	public void update(Student student) {
		studentDao.update(student);
		
	}

}
