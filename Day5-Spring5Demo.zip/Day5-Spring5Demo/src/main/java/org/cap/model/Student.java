package org.cap.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	@GeneratedValue
	@Column(name="studId")
	private int studId;
	@Column(name="studName")
	private String studName;
	@Column(name="location")
	private String location;
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", location=" + location + "]";
	}
	public Student(int studId, String studName, String location) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.location = location;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
