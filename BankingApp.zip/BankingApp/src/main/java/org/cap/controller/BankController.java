package org.cap.controller;

import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BankController {

	@RequestMapping("/validateLogin")
	public String validateLogin (ModelMap map,
			@RequestParam("userName")String username, 
			@RequestParam("password")String password) {
		if(username.equals("sandy") && password.equals("sandy")){
			return "main";
	}
	return "redirect:/";
	}
	
	@RequestMapping("/createAccount")
	public String showCreateAccount() {
		return "createAccount";
	}
	
	@RequestMapping("/showBalance")
	public String showBalance() {
		return "showBalance";
	}
	
	@RequestMapping("/deposit")
	public String depositAmount() {
		return "deposit";
	}
	
	@RequestMapping("/withdraw")
	public String withdrawAmount() {
		return "withdraw";
	}
	
	@RequestMapping("/fundTransfer")
	public String fundTransfer() {
		return "fundTransfer";
	}
	
	@RequestMapping("/transaction")
	public String transactionSummary() {
		return "transaction";
	}
	
	@RequestMapping("/logout")
	public String logout() {
		return "redirect:/";
	}
}
