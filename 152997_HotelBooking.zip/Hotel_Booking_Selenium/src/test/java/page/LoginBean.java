package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginBean {

	WebDriver driver;
	
	@FindBy(name="userName")
	private WebElement username;
	
	@FindBy(name="userPwd")
	private WebElement password;
	
	@FindBy(className="btn")
	private WebElement login;
	
	public LoginBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setUsername(String usrname)
	{
		this.username.sendKeys(usrname);
	}
	public void setPassword(String pass)
	{
		this.password.sendKeys(pass);
	}
	public void setLogin()
	{
		this.login.submit();
	}
	
	/*public void login_successful(String username,String password) {
		 this.setUsername(username);
		 this.setPassword(password);
		 this.setLogin();
	}*/

	
}
