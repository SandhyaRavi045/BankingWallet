package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingBean {
	
	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;

	@FindBy(name="Email")
	private WebElement email;
	
	@FindBy(name="Phone")
	private WebElement phone;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[7]/td[2]/select")
	private WebElement city;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[8]/td[2]/select")
	private WebElement state;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[10]/td[2]/select")
	private WebElement persons;
	
	@FindBy(name="txtCardholderName")
	private WebElement cardholder;
	
	@FindBy(name="debit")
	private WebElement debitNo;
	
	@FindBy(name="txtCvv")
	private WebElement cvvNo;
	
	@FindBy(name="txtMonth")
	private WebElement month;
	
	@FindBy(name="txtYear")
	private WebElement year;
	
	@FindBy(className="btn")
	private WebElement payment;
	
	public HotelBookingBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setFirstName(String fname)
	{
		this.firstName.sendKeys(fname);
	}
	
	public void setLastName(String lname)
	{
		this.lastName.sendKeys(lname);
	}
	
	public void setEmail(String emailid)
	{
		this.email.sendKeys(emailid);
	}
	
	public void setPhone(String phoneno)
	{
		this.email.sendKeys(phoneno);
	}
	
	public void setCity(String c)
	{
		Select sel= new Select(city);
		sel.selectByVisibleText(c);
	}
	
	public void setState(String s)
	{
		Select sel= new Select(state);
		sel.selectByVisibleText(s);
	}
	
	public void setPersons(String p)
	{
		Select sel= new Select(persons);
		sel.selectByVisibleText(p);
	}
	
	public void setCardholder(String name)
	{
		this.cardholder.sendKeys(name);
	}
	
	public void setDebitNo(String debit)
	{
		this.debitNo.sendKeys(debit);
	}
	
	public void setCvvNo(String cvv)
	{
		this.cvvNo.sendKeys(cvv);
	}
	
	public void setMonth(String expmon)
	{
		this.month.sendKeys(expmon);
	}
	
	public void setYear(String expyear)
	{
		this.year.sendKeys(expyear);
	}
	
	public void setPayment()
	{
		this.payment.submit();
	}
	
	/*public void payment_successful(String fname,String lname,String emailid, String phoneno,String c, String s, String p,
			String name, String debit, String cvv, String expmon, String expyear) {
		 this.setFirstName(fname);
		 this.setLastName(lname);
		 this.setEmail(emailid);
		 this.setPhone(phoneno);
		 this.setCity(c);
		 this.setState(s);
		 this.setPersons(p);
		 this.setCardholder(name);
		 this.setDebitNo(debit);
		 this.setCvvNo(cvv);
		 this.setMonth(expmon);
		 this.setYear(expyear);
		 this.setPayment();
	}*/
	
}
