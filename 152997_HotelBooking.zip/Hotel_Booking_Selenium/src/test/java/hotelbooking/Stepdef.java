package hotelbooking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.HotelBookingBean;
import page.LoginBean;

public class Stepdef {
	
	WebDriver driver;
	private LoginBean loginBean;
	private HotelBookingBean hotelBookingBean;
	
	@Before
	public void setup() {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\sandhyr\\Downloads\\chromedriver.exe");
		driver=new ChromeDriver();
		loginBean=new LoginBean(driver);
		hotelBookingBean=new HotelBookingBean(driver);
	}

	@Given("^hotel login page$")
	public void hotel_login_page() throws Throwable {
	    driver.get("D:\\CucumberDemo\\Hotel_Booking_Selenium\\src\\main\\webapp\\WEB-INF\\login.html");
	}

	@When("^I click login without entering username$")
	public void i_click_login_without_entering_username() throws Throwable {
		loginBean.setLogin();	    
	}

	@Then("^displayed in alert Please enter UserName$")
	public void displayed_in_alert_Please_enter_UserName() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter userName.");
    	Thread.sleep(500);
	}

	@When("^I enter username and click login$")
	public void i_enter_username_and_click_login() throws Throwable {
		driver.switchTo().alert().accept();
	    loginBean.setUsername("capgemini");
	    loginBean.setLogin();
	}

	@Then("^displayed in alert Please enter password$")
	public void displayed_in_alert_Please_enter_password() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter password.");
    	Thread.sleep(500);
	}

	@When("^I click login$")
	public void i_click_login() throws Throwable {
		driver.switchTo().alert().accept();
		loginBean.setUsername("capgemini");
		loginBean.setPassword("capg1234");
		loginBean.setLogin();
		
	}

	@Then("^navigate to hotelbooking page$")
	public void navigate_to_hotelbooking_page() throws Throwable {
		driver.get("D:\\\\CucumberDemo\\\\Hotel_Booking_Selenium\\\\src\\\\main\\\\webapp\\\\WEB-INF\\\\hotelbooking.html");
		
	}

	@When("^I click Confirm Booking$")
	public void i_click_Confirm_Booking() throws Throwable {
	    hotelBookingBean.setPayment();
	}

	@Then("^displayed in alert Please fill the First Name$")
	public void displayed_in_alert_Please_fill_the_First_Name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the First Name");
    	Thread.sleep(500);
	}

	@When("^I enter firstname and click Confirm Booking$")
	public void i_enter_firstname_and_click_Confirm_Booking() throws Throwable {
		driver.switchTo().alert().accept();
	    hotelBookingBean.setFirstName("Sandhya");
	    hotelBookingBean.setPayment();
	}

	@Then("^display in alert Please fill the Last Name$")
	public void display_in_alert_Please_fill_the_Last_Name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Last Name");
    	Thread.sleep(500);
	}

	@When("^I enter lastname and click Confirm Booking$")
	public void i_enter_lastname_and_click_Confirm_Booking() throws Throwable {
		driver.switchTo().alert().accept();
	    hotelBookingBean.setFirstName("Sandhya");
	    hotelBookingBean.setLastName("Ravi");
	    hotelBookingBean.setPayment();
	}

	@Then("^display in alert Please fill the Email$")
	public void display_in_alert_Please_fill_the_Email() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
    	Thread.sleep(500);
	}

	@When("^I enter Email and click Confirm Booking$")
	public void i_enter_Email_and_click_Confirm_Booking() throws Throwable {
		driver.switchTo().alert().accept();
	    hotelBookingBean.setFirstName("Sandhya");
	    hotelBookingBean.setLastName("Ravi");
	    hotelBookingBean.setEmail("san@gmail.com");
	    hotelBookingBean.setPayment();
	}

	@Then("^display in alert Please fill the Mobile No$")
	public void display_in_alert_Please_fill_the_Mobile_No() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Mobile No");
    	Thread.sleep(500);
	}

	@When("^I enter invalid Email and click Confirm Booking$")
	public void i_enter_invalid_Email_and_click_Confirm_Booking() throws Throwable {
		driver.switchTo().alert().accept();
	    hotelBookingBean.setFirstName("Sandhya");
	    hotelBookingBean.setLastName("Ravi");
	    hotelBookingBean.setEmail("san");
	    hotelBookingBean.setPayment();
	}

	@Then("^display in alert Please enter valid Email Id\\.$")
	public void display_in_alert_Please_enter_valid_Email_Id() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id.");
    	Thread.sleep(500);
	}

	@When("^I enter Mobile No and click Confirm Booking$")
	public void i_enter_Mobile_No_and_click_Confirm_Booking() throws Throwable {
		driver.switchTo().alert().accept();
	    hotelBookingBean.setFirstName("Sandhya");
	    hotelBookingBean.setLastName("Ravi");
	    hotelBookingBean.setEmail("san@gmail.com");
	    hotelBookingBean.setPhone("9888998888");
	    hotelBookingBean.setPayment();
	}

	@Then("^display in alert Please fill the Address$")
	public void display_in_alert_Please_fill_the_Address() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Address");
    	Thread.sleep(500);
	}

	@When("^I enter invalid Mobile No and click Confirm Booking$")
	public void i_enter_invalid_Mobile_No_and_click_Confirm_Booking() throws Throwable {
		driver.switchTo().alert().accept();
	    hotelBookingBean.setFirstName("Sandhya");
	    hotelBookingBean.setLastName("Ravi");
	    hotelBookingBean.setEmail("san@gmail.com");
	    hotelBookingBean.setPhone("9888998");
	    hotelBookingBean.setPayment();
	}

	@Then("^display in alert Please enter valid Contact no\\.$")
	public void display_in_alert_Please_enter_valid_Contact_no() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Contact no.");
    	Thread.sleep(500);
	}

	@When("^I enter Address and click Confirm Booking$")
	public void i_enter_Address_and_click_Confirm_Booking() throws Throwable {
		driver.switchTo().alert().accept();
	    hotelBookingBean.setFirstName("Sandhya");
	    hotelBookingBean.setLastName("Ravi");
	    hotelBookingBean.setEmail("san@gmail.com");
	    hotelBookingBean.setPhone("9888998888");
	    hotelBookingBean.setPayment();
	}

	@Then("^display in alert Please select city$")
	public void display_in_alert_Please_select_city() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select city");
    	Thread.sleep(500);
	}

	@When("^I enter city and click Confirm Booking$")
	public void i_enter_city_and_click_Confirm_Booking() throws Throwable {
	    
	}

	@Then("^display in alert Please select state$")
	public void display_in_alert_Please_select_state() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select state");
    	Thread.sleep(500);
	}

	@When("^I enter state and click Confirm Booking$")
	public void i_enter_state_and_click_Confirm_Booking() throws Throwable {
	    
	}

	@Then("^display in alert Please fill the Number of people attending$")
	public void display_in_alert_Please_fill_the_Number_of_people_attending() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Number of people attending");
    	Thread.sleep(500);
	}

	@When("^I enter Number of people attending and click Confirm Booking$")
	public void i_enter_Number_of_people_attending_and_click_Confirm_Booking() throws Throwable {
	    
	}

	@Then("^display in alert Please fill the Card holder name$")
	public void display_in_alert_Please_fill_the_Card_holder_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
    	Thread.sleep(500);
	}

	@When("^I enter Card holder name and click Confirm Booking$")
	public void i_enter_Card_holder_name_and_click_Confirm_Booking() throws Throwable {
	    
	}

	@Then("^display in alert Please fill the Debit card Number$")
	public void display_in_alert_Please_fill_the_Debit_card_Number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
    	Thread.sleep(500);
	}

	@When("^I enter Debit card Number and click Confirm Booking$")
	public void i_enter_Debit_card_Number_and_click_Confirm_Booking() throws Throwable {
	    
	}

	@Then("^display in alert Please fill the cvv$")
	public void display_in_alert_Please_fill_the_cvv() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the cvv");
    	Thread.sleep(500);
	}

	@When("^I enter cvv and click Confirm Booking$")
	public void i_enter_cvv_and_click_Confirm_Booking() throws Throwable {
	    
	}

	@Then("^display in alert Please fill expiration month$")
	public void display_in_alert_Please_fill_expiration_month() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the expiration month");
    	Thread.sleep(500);
	}

	@When("^I enter expiration month and click Confirm Booking$")
	public void i_enter_expiration_month_and_click_Confirm_Booking() throws Throwable {
	    
	}

	@Then("^display in alert Please fill the expiration year$")
	public void display_in_alert_Please_fill_the_expiration_year() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the expiration year");
    	Thread.sleep(500);
	}

	@When("^I enter expiration year and click Confirm Booking$")
	public void i_enter_expiration_year_and_click_Confirm_Booking() throws Throwable {
	    /*hotelBookingBean.payment_successful("Sandhya", "Ravi", "sandy@gmail.com", "9888999898", "Bangalore", "Karnataka", "4", "Sandhya", "1222333344443333", "122", "September", "2020");*/
	}

	@Then("^navigate to Booking Successful page$")
	public void navigate_to_Booking_Successful_page() throws Throwable {
		driver.get("D:\\\\CucumberDemo\\\\Hotel_Booking_Selenium\\\\src\\\\main\\\\webapp\\\\WEB-INF\\\\success.html");
	}


}
