package com.BankingWallet.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.BankingWallet.bean.Customer;
import com.BankingWallet.exception.BankingException;
import com.BankingWallet.servcie.BankingService;
import com.BankingWallet.servcie.BankingServiceImpl;


public class BankingDaoTest {

	BankingService bs;

	@Before
	public void setup() {
		bs = new BankingServiceImpl();
	}
	
	@After
	public void teardown() {
		bs = null;
	}
	
	@Test
	public void testCreateAccount() {
		try {
			Customer cust = new Customer();
			cust.setCustomerName("sandy");
			cust.setMobile("99999999999");
			cust.setMailId("sandy@gmail.com");
			assertNotEquals(bs.createAccount(cust),22);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testLogin() {
		try {
			assertEquals(bs.login(1, "sandy"), true);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetBalance() {
		try {
			assertEquals(bs.getBalance(3), 1234567, 0.0);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testDepositAcc() {
		try {
			assertEquals(bs.depositAmount(1, 1000),true);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testWithdrawAcc() {
		try {
			assertEquals(bs.withdrawAmount(1, 1000),true);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testTransferAcc() {
		try {
			assertEquals(bs.transferAmount(1,2,1),true);
			assertEquals(bs.transferAmount(2,1,1),true);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testPrintTransaction() {
		try {
			assertEquals(bs.printTransaction(1),false);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
