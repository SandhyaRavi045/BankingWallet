package org.cap.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;


@Entity
public class Pilot{
	
	@Id
	@GeneratedValue
	private int pilotId;
	@NotEmpty(message="*Please enter First name")
	private String firstName;
	@NotEmpty(message="*Please enter Last name")
	private String lastName;
	@Past(message="Please enter Past date")
	private Date dateOfBirth;
	@Future(message="Please enter Future date")
	private Date dateOfJoining;
	private Boolean isCertified;
	@Range(min=10000, max=100000, message="*please enter between 10000 to 100000")
	private double salary;
	@NotBlank(message="Please enter mail ID")
	@Email(message="Please enter valid mail")
	private String mailId;
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	
	public Boolean getIsCertified() {
		return isCertified;
	}
	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", dateOfJoining=" + dateOfJoining + ", isCertified=" + isCertified + ", salary="
				+ salary + ", mailId=" + mailId + "]";
	}
	
	
	
	public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoining,
			Boolean isCertified, double salary, String mailId) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoining = dateOfJoining;
		this.isCertified = isCertified;
		this.salary = salary;
		this.mailId = mailId;
	}
	public Pilot() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
