package forgotpassword;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.ForgotPasswordBean;

public class Stepdef {
	
	private WebDriver driver;
	private ForgotPasswordBean forgotPasswordBean;
		
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		driver=new ChromeDriver();
		forgotPasswordBean=new ForgotPasswordBean(driver);
	}

	@Given("^Forgot password page loaded$")
	public void forgot_password_page_loaded() throws Throwable {
		driver.get("http://localhost:8085/capstore/forgot");
	}

	@When("^user simply clicks on verify email$")
	public void user_simply_clicks_on_verify_email() throws Throwable {
		forgotPasswordBean.setVerify();
	    
	}

	@Then("^display error message saying please enter email for verification$")
	public void display_error_message_saying_please_enter_email_for_verification() throws Throwable {
	    
	}

	@When("^user enters email$")
	public void user_enters_email() throws Throwable {
		forgotPasswordBean.setEmailId("sandhya@gmail.com");
	    
	}

	@When("^clicks on verify email$")
	public void clicks_on_verify_email() throws Throwable {
		forgotPasswordBean.setVerify();
	}

	@Then("^navigate to change password page$")
	public void navigate_to_change_password_page() throws Throwable {
	    
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
	    forgotPasswordBean.setEmailId("sandhya");
	    forgotPasswordBean.setVerify();
	}

	@Then("^display error message saying please enter valid email$")
	public void display_error_message_saying_please_enter_valid_email() throws Throwable {
	    
	}

	@After
	public void shutdown() {
		driver.close();
	}
}
