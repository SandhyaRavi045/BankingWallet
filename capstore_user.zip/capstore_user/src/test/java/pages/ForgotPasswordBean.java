package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ForgotPasswordBean {

	@FindBy(name="email")
	private WebElement emailId;
	
	@FindBy(name="recover-submit")
	private WebElement verify;
	
	private WebDriver driver;
	
	public ForgotPasswordBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setEmailId(String email) {
		emailId.sendKeys(email);
	}
	
	public void setVerify() {
		verify.click();
	}
	
}
