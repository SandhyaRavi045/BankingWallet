package encryption;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {

	@Given("^user enters password$")
	public void user_enters_password() throws Throwable {
	    
	}

	@When("^it matches validation criteria$")
	public void it_matches_validation_criteria() throws Throwable {
	    
	}

	@Then("^encrypt and store the password in database$")
	public void encrypt_and_store_the_password_in_database() throws Throwable {
	    
	}

}
