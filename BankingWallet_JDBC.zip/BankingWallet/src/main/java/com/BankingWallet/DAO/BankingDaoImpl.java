package com.BankingWallet.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.BankingWallet.DB.DBConnection;
import com.BankingWallet.bean.Customer;
import com.BankingWallet.bean.Transaction;
import com.BankingWallet.exception.BankingException;



public class BankingDaoImpl implements BankingDao {
Logger logger=Logger.getRootLogger();
int transid=0;
	
	
	public  BankingDaoImpl() {
		
		PropertyConfigurator.configure("resources//log4j.properties");
	}
		
		

	@SuppressWarnings("resource")
	
	public boolean login(int accountNumber, String password) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;	
		ResultSet rs=null;
		
		String result=null;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.GET_VALIDATE);
			preparedStatement.setInt(1,accountNumber);
			rs=preparedStatement.executeQuery();
			rs.next();
			result=rs.getString("password");

		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankingException("Tehnical problem occured refer log");
		}
		try {
			if(!result.equals(password)) {
				throw new BankingException("Incorrect password");
			}
			return true;
		} catch (BankingException e) {
			throw new BankingException(e.getMessage());
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankingException("Error in closing db connection");	
			}
		}
		
	}

	
	public boolean depositAmount(int accNo, double amount) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement prepareStatement = null;
		PreparedStatement prepareStatement1=null;
		ResultSet resultSet=null,resultSet2=null;
		int queryResult=0,queryresult1=0;
		try {
			prepareStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
			prepareStatement.setDouble(1, amount);
			prepareStatement.setLong(2, accNo);
			queryResult = prepareStatement.executeUpdate();
			prepareStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			prepareStatement.setInt(1,accNo);
			resultSet=prepareStatement.executeQuery();

			if(resultSet.next())
			{
				double balance= resultSet.getDouble("Balance");
				prepareStatement1=connection.prepareStatement(QueryMapper.transaction_query1);
				prepareStatement1.setString(1,"deposit");
				prepareStatement1.setDouble(2,amount);
				prepareStatement1.setLong(4,accNo);
				PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
				resultSet2=Date.executeQuery();
				if(resultSet2.next())
				{
					Date date=resultSet2.getDate(1);
					prepareStatement1.setDate(3,date);
					
				}
				queryresult1=prepareStatement1.executeUpdate();
				prepareStatement = connection.prepareStatement(QueryMapper.transaction_query_sequence);
				resultSet=prepareStatement.executeQuery();

				if(resultSet.next())
				{
					transid=resultSet.getInt(1);
							
				}
			}
			else
			{
				throw new BankingException("Enter correct account number and pin");
			}
			return true;			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new BankingException("Technical problem occured refer log");
		}
		finally {
			try {
				prepareStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new BankingException("Error in closing DB connection");
			}			
		}
	}

	
	public int createAccount(Customer customer) throws BankingException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_CUSTOMER);

			preparedStatement.setString(1, customer.getCustomerName());
			preparedStatement.setString(2, customer.getMobile());
			preparedStatement.setString(3, customer.getMailId());
			preparedStatement.setString(4, customer.getPanNumber());
			preparedStatement.setString(5, customer.getAddress());
			preparedStatement.setString(6, customer.getAadharNumber());
			preparedStatement.setDouble(7, customer.getBalance());
			preparedStatement.setString(8, customer.getPassword());
			
					
			queryResult=preparedStatement.executeUpdate();
			return queryResult;
			
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankingException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankingException("Error in closing db connection");	
			}
		}
		
	}

	
	@Override
	public double getBalance(int accNo) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;	
		ResultSet rs=null;
		
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			preparedStatement.setInt(1,accNo);
			rs=preparedStatement.executeQuery();
			rs.next();
			double result=rs.getDouble("balance");
			return result;

		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new BankingException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new BankingException("Error in closing db connection");	
			}
		}
	}

	
	public boolean withdrawAmount(int accNo, double amount) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet=null,resultSet2=null;
		int queryresult=0;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			preparedStatement.setInt(1,accNo);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
			float balance1= resultSet.getFloat("Balance");
			if(balance1<amount)
					throw new BankingException("insufficient balance in your account");
			else
			{	
				preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
				preparedStatement.setDouble(1, amount);
				preparedStatement.setInt(2, accNo);
				queryresult = preparedStatement.executeUpdate();
				preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
				preparedStatement.setInt(1,accNo);
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					float balance= resultSet.getFloat("Balance");
					preparedStatement1=connection.prepareStatement(QueryMapper.transaction_query1);
					preparedStatement1.setString(1,"withdraw");
					preparedStatement1.setDouble(2,amount);
					preparedStatement1.setInt(4,accNo);
					PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
					resultSet2=Date.executeQuery();
					if(resultSet2.next())
					{
						Date date=resultSet2.getDate(1);
						preparedStatement1.setDate(3,date);
						
					}
					queryresult=preparedStatement1.executeUpdate();
					preparedStatement = connection.prepareStatement(QueryMapper.transaction_query_sequence);
					resultSet=preparedStatement.executeQuery();

					if(resultSet.next())
					{
						transid= resultSet.getInt(1);
								
					}
				}else
					throw new BankingException("invalid details");
			}
			}else
				throw new BankingException("invalid details");
			return true;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new BankingException("Technical problem occured refer log");
		}
		finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new BankingException("Error in closing DB connection");
			}			
		}
	}
	
	
	public boolean transferAmount(int accNo, int accNo2, double amount) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		PreparedStatement preparedStatement1=null;	
		ResultSet resultSet2 = null;
		int queryResult=0;
				if(amount<=0)
					throw new BankingException("for fund to be transfered fund must be greater than 0");
				else
				{
				try
				{
					
					preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
					preparedStatement.setInt(1,accNo2);
					resultSet=preparedStatement.executeQuery();
					if(resultSet.next())
					{
					double balance1= resultSet.getDouble("Balance");
					if(balance1<amount)
							throw new BankingException("Low balance for fundtranfer");
					
					else 
						{
						
						preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
						preparedStatement.setDouble(1, amount);
						preparedStatement.setInt(2, accNo);
						queryResult = preparedStatement.executeUpdate();
						
						preparedStatement1=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
						preparedStatement1.setDouble(1, amount);
						preparedStatement1.setInt(2, accNo2);
						queryResult = preparedStatement1.executeUpdate();
						
						preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
						preparedStatement.setInt(1,accNo2);
						resultSet=preparedStatement.executeQuery();
						if(resultSet.next())
						{
						float balance2= resultSet.getFloat("Balance");
						preparedStatement1=connection.prepareStatement(QueryMapper.transaction_query1);
						preparedStatement1.setString(1,"fundtransfer(DB)");
						preparedStatement1.setDouble(2,amount);
						preparedStatement1.setInt(4,accNo2);
						PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
						resultSet2=Date.executeQuery();
						if(resultSet2.next())
						{
							Date date=resultSet2.getDate(1);
							preparedStatement1.setDate(3,date);
							
						}
						queryResult=preparedStatement1.executeUpdate();
						preparedStatement1=connection.prepareStatement(QueryMapper.transaction_query1);
						preparedStatement1.setString(1,"fundtransfer(cr)");
						preparedStatement1.setDouble(2,amount);
						preparedStatement1.setInt(4,accNo);
						PreparedStatement date1=connection.prepareStatement(QueryMapper.date_query);
						resultSet2=date1.executeQuery();
						if(resultSet2.next())
						{
							Date d=resultSet2.getDate(1);
							preparedStatement1.setDate(3,d);
						}
						queryResult=preparedStatement1.executeUpdate();
						preparedStatement = connection.prepareStatement(QueryMapper.transaction_query_sequence);
						resultSet=preparedStatement.executeQuery();

						if(resultSet.next())
						{
							transid= resultSet.getInt(1);
									
						}
						return true;
						}else
							throw new BankingException("invalid account detailsdetails");
					}
					}else
						throw new BankingException("invalid details");
				}
					catch(SQLException sqlException)
				{
				logger.error(sqlException.getMessage());
				sqlException.printStackTrace();
				throw new BankingException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					throw new BankingException("Error in closing db connection");	
				}
			}
		}		
		
	}


	
	public boolean printTransaction(int accNo) throws BankingException {
		Transaction t=new Transaction();
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.transaction_query2);
			preparedStatement.setLong(1,accNo);	
			resultSet=preparedStatement.executeQuery();
						while(resultSet.next()) {
							t.setTransid(resultSet.getInt("transid"));
							t.setAccountno(resultSet.getInt("accountno"));
							t.setAmount(resultSet.getDouble("amount"));
							t.setTransfertype(resultSet.getString("transfertype"));
							t.setTransDate(resultSet.getDate("transDate"));
							System.out.println(t);
			}
		}catch(SQLException sqlException)
		{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new BankingException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new BankingException("Error in closing db connection");	
		}
	}return true;
}
}
