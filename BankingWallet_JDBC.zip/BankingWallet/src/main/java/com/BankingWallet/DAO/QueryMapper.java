package com.BankingWallet.DAO;

public interface QueryMapper {
	
	public static final String INSERT_CUSTOMER="INSERT INTO Customer VALUES(Customer_sequence.NEXTVAL,?,?,?,?,?,?,?,?)";
	public static final String INSERT_TRANSACTION="INSERT INTO Transaction VALUES(Transaction_sequence.NEXTVAL,?,?,?)";
	public static final String UPDATE_CUSTOMER_DEPOSIT="UPDATE Customer SET balance=balance+? WHERE account_number=?";
	public static final String UPDATE_CUSTOMER_WITHDRAW="UPDATE Customer SET balance=balance-? WHERE account_number=?";
	public static final String VIEW_BALANCE_CUSTOMER="SELECT balance FROM Customer WHERE account_number=?";
	public static final String PRINT_TRANSACTION="SELECT account_number, amount FROM transaction WHERE account_number=?";
	public static final String GET_VALIDATE="SELECT password FROM Customer WHERE account_number=?";
	public static final String ACCOUNTNO_SEQUENCE="SELECT CUSTOMER_SEQUENCE.CURRVAL FROM DUAL";
    public static final String transaction_query1="insert into transaction values(transid_sequence.NEXTVAL,?,?,?,?)";
    public static final String date_query="select sysdate from dual";
    public static final String transaction_query_sequence="select transid_sequence.CURRVAL from dual";
    public static final String transaction_query2="select * from transaction where accountno=?";
}


/******************TABLESCRIPT*******************
CREATE TABLE Customer(
account_number NUMBER(10),
customer_name VARCHAR2(30),
mobile NUMBER(10),
mail_id VARCHAR2(30),
pan_number VARCHAR2(15),
address VARCHAR2(50),
aadhar_number NUMBER(12),
balance FLOAT,
password VARCHAR2(30),
transaction VARCHAR2(100)
);


************************************************/