package com.BankingWallet.bean;

import java.sql.Date;

public class Transaction {
	private int transid;
	private String transfertype;
	private Date transDate;
	private double amount;
	
	private int accountno;

	public int getTransid() {
		return transid;
	}

	public void setTransid(int transid) {
		this.transid = transid;
	}

	public String getTransfertype() {
		return transfertype;
	}

	public void setTransfertype(String transfertype) {
		this.transfertype = transfertype;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getAccountno() {
		return accountno;
	}

	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}

	@Override
	public String toString() {
		return "Transaction [transid=" + transid + ", transfertype=" + transfertype + ", transDate=" + transDate
				+ ", amount=" + amount + ", accountno=" + accountno + "]";
	}

	public Transaction(int transid, String transfertype, Date transDate, double amount, int accountno) {
		super();
		this.transid = transid;
		this.transfertype = transfertype;
		this.transDate = transDate;
		this.amount = amount;
		this.accountno = accountno;
	}

	public Transaction() {
		super();
		
	}
	
}
