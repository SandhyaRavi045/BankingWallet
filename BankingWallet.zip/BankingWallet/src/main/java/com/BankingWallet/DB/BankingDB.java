package com.BankingWallet.DB;

import java.util.HashMap;

import com.BankingWallet.bean.Customer;

public class BankingDB {
	
	private static HashMap<Integer, Customer> requestMap=new HashMap<Integer,Customer>();
	public static HashMap<Integer, Customer> getBankingMap(){
		return requestMap;
		
	}
	static {
		requestMap.put(1001, new Customer("Motu", 1001, "9999999999", "motu@gmail.com", "ABCDE1234A", "Chennai", "123456789123", 25000, "patlu", null));
		requestMap.put(1002, new Customer("Patlu", 1002, "9999988888", "patlu@gmail.com", "ABCDE1234B", "Chennai", "123456789121", 30000, "motu", null));
	}
}
