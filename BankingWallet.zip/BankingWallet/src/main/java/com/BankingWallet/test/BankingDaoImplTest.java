package com.BankingWallet.test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.BankingWallet.exception.BankingException;
import com.BankingWallet.servcie.BankingService;
import com.BankingWallet.servcie.BankingServiceImpl;

public class BankingDaoImplTest {
BankingService bankingService;
	
	@Before
	public void setup() {
		bankingService=new BankingServiceImpl();
	}
	
	@After
	public void teardown() {
		bankingService=null;
	}
	
	@Test
	public void testLogin() {
		try {
			assertEquals(bankingService.login(1001, "patlu"), true);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testCreateAccount() {
		try {
			assertEquals(bankingService.createAccount("Sandhya", "sandy"), 1003);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testDepositAmount() {
		try {
			assertEquals(bankingService.depositAmount(1003, 5000), 5000, 0.0);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetBalance() {
		try {
			assertEquals(bankingService.getBalance(1001), 25000, 0.0);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testWithdrawAmount() {
		try {
			assertEquals(bankingService.withdrawAmount(1003, 3000), 2000, 0.0);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testTransferAmount() {
		try {
			assertEquals(bankingService.transferAmount(1001, 1002, 0), true);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testPrintTransaction() {
		try {
			assertEquals(bankingService.printTransaction(1002), "No Transactions");
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

}
