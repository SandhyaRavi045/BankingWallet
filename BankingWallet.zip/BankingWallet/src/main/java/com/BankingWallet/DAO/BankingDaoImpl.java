package com.BankingWallet.DAO;

import java.util.HashMap;
import java.util.Optional;

import com.BankingWallet.DB.BankingDB;
import com.BankingWallet.bean.Customer;
import com.BankingWallet.exception.BankingException;



public class BankingDaoImpl implements BankingDao {

	static HashMap<Integer,Customer> requestMap=BankingDB.getBankingMap();
	Customer customerRequest=new Customer();
	String app=null;
	String sum=null;
	
	@Override
	public boolean login(int accountNumber, String password) throws BankingException {
		try {
			Customer request=requestMap.get(accountNumber);
			if(request==null) {
				throw new BankingException("Incorrect username");
			}
			else {
				if(password.equals(request)){
					throw new BankingException("Incorrect password");
				}
			}
		} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
		return true;
	}

	@Override
	public int createAccount(String username, String password) throws BankingException {
		
		try {
			if(requestMap.size()==0) {
				customerRequest.setAccountNumber(1001);
			}
			else {
				Optional <Integer> accNo=requestMap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int accNumber=accNo.get()+1;
				customerRequest.setAccountNumber(accNumber);
			}
			
			requestMap.put(customerRequest.getAccountNumber(), customerRequest);
			return customerRequest.getAccountNumber();
		} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
	}

	@Override
	public double depositAmount(int accNo, double amount) throws BankingException {
		Customer customerRequest=new Customer();
		try {
			customerRequest=requestMap.get(accNo);
			double balance=customerRequest.getBalance();
			balance+=amount;
			customerRequest.setBalance(balance);
			if(customerRequest.getTransaction()==null) {
				customerRequest.setTransaction("Account number: "+accNo+" credited with "+amount);
			}
			else {
			app="\nAccount number: "+accNo+" credited with "+amount;
			sum=customerRequest.getTransaction()+app;
			customerRequest.setTransaction(sum);
			}
			requestMap.put(accNo, customerRequest);
			return customerRequest.getBalance();
		} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
	}

	@Override
	public double getBalance(int accNo) throws BankingException {
		Customer customerRequest=new Customer();
		try {
			customerRequest=requestMap.get(accNo);
			if(customerRequest==null) {
				throw new BankingException("Invalid account number");
			}
		return customerRequest.getBalance();
		} catch(Exception e) {
			throw new BankingException(e.getMessage());
		}
	}

	@Override
	public double withdrawAmount(int accNo, double amount) throws BankingException {
		Customer customerRequest=new Customer();
		try {
			customerRequest=requestMap.get(accNo);
			double balance=customerRequest.getBalance();
			balance-=amount;
			customerRequest.setBalance(balance);
			if(customerRequest.getTransaction()==null) {
				customerRequest.setTransaction("Account number: "+accNo+" has withdrawn "+amount);
			}
			else {
			app="\nAccount number: "+accNo+" has withdrawn "+amount;
			sum=customerRequest.getTransaction()+app;
			customerRequest.setTransaction(sum);
			}
			requestMap.put(accNo, customerRequest);
			return customerRequest.getBalance();
			} catch (Exception e) {
				throw new BankingException(e.getMessage());
			}
	}
	@Override
	public boolean transferAmount(int accNo, int accNo2, double amount) throws BankingException {
		Customer customerRequest=new Customer();
		Customer customerRequest1=new Customer();
		try {
			customerRequest=requestMap.get(accNo);
			double balance=customerRequest.getBalance();
			System.out.println("Initial balance in:"+accNo+" is: "+balance);
			balance-=amount;
			customerRequest.setBalance(balance);
			if(customerRequest.getTransaction()==null) {
				customerRequest.setTransaction("Account number: "+accNo+" has deposited "+amount+" in account "+accNo2);
			}
			else {
			app="\nFund Transfer: "+accNo+" has deposited "+amount+" in account "+accNo2;
			sum=customerRequest.getTransaction()+app;
			customerRequest.setTransaction(sum);
			}
			requestMap.put(accNo, customerRequest);
			System.out.println("New balance in:"+accNo+" is: "+customerRequest.getBalance());
			customerRequest1=requestMap.get(accNo2);
			balance=customerRequest1.getBalance();
			System.out.println("Initial balance in:"+accNo2+" is: "+balance);
			balance+=amount;
			customerRequest1.setBalance(balance);
			if(customerRequest1.getTransaction()==null) {
				customerRequest1.setTransaction("Account number: "+accNo2+" credited with "+amount+" from account "+accNo);
			}
			else {
			app="\nFund Transfer: "+accNo2+" credited with "+amount+" from account "+accNo;
			sum=customerRequest.getTransaction()+app;
			customerRequest.setTransaction(sum);
			}
			requestMap.put(accNo2, customerRequest1);
			System.out.println("New balance in:"+accNo2+" is: "+customerRequest1.getBalance());
			return true;
		} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
		
	}

	@Override
	public String printTransaction(int accNo) throws BankingException {
		String str="No Transactions";
		Customer customerRequest=new Customer();
		try {
			customerRequest=requestMap.get(accNo);
			if(customerRequest==null) {
				throw new BankingException("Invalid account number");
			}
			if(customerRequest.getTransaction()==null) {
				return str;
			}
			else {
				return customerRequest.getTransaction();
			}
	} catch(Exception e) {
		throw new BankingException(e.getMessage());
	}
	}
}
