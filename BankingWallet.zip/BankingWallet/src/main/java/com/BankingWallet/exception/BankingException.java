package com.BankingWallet.exception;

public class BankingException extends Exception{
	
	public BankingException() {
		super();
	}
	public BankingException(String message) {
		super(message);
	}
}
