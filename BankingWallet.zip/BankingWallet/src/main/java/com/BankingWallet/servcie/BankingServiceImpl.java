package com.BankingWallet.servcie;

import com.BankingWallet.DAO.BankingDao;
import com.BankingWallet.DAO.BankingDaoImpl;
import com.BankingWallet.bean.Customer;
import com.BankingWallet.exception.BankingException;

public class BankingServiceImpl implements BankingService{

	BankingDao bankingDao=new BankingDaoImpl();
	@Override
	public boolean validate(Customer customerRequest) throws BankingException {
		if(validateName(customerRequest.getCustomerName())&&validateMobile(customerRequest.getMobile())&&validateAadhar(customerRequest.getAadharNumber())&&(validatePAN(customerRequest.getPanNumber()))) {
			return true;
		}
		return false;
	}

	private boolean validatePAN(String panNumber) throws BankingException {
		if(panNumber.isEmpty() && panNumber==null) {
			throw new BankingException("Pan number cannot be empty");
		}
		else {
			if(!panNumber.matches("[A-Z]{5}\\d{4}[A-Z]")) {
				throw new BankingException("Pan number is not valid");
			}
		}
		return true;
	}

	private boolean validateAadhar(String aadharNumber) throws BankingException {
		if(aadharNumber.isEmpty() || aadharNumber==null) {
			throw new BankingException("Aadhar number cannot be empty");
		}
		else {
			if(!aadharNumber.matches("\\d{12}")) {
				throw new BankingException("Aadhar number should be 12 digits");
			}
		}
		return true;
	}

	private boolean validateMobile(String mobile) throws BankingException {
		if(mobile.isEmpty() || mobile==null) {
			throw new BankingException("Phone number cannot be empty");
		}
		else {
			if(!mobile.matches("\\d{10}")) {
				throw new BankingException("Phone number should be 10 digits");
			}
		}
		return true;
	}

	private boolean validateName(String customerName) throws BankingException {
		if(customerName.isEmpty() && customerName==null) {
			throw new BankingException("Customer name cannot be empty");
		}
		else {
			if(!customerName.matches("[A-Z][A-Za-z]{2,}")) {
				throw new BankingException("Customer name should start with capital letter and min 3 alphabets");
			}
		}
		return true;
	}


	
	
	@Override
	public boolean login(int accNo, String pass) throws BankingException {
		
		return bankingDao.login(accNo, pass);
	}

	@Override
	public int createAccount(String username, String password) throws BankingException {
		return bankingDao.createAccount(username,password);
	}


	

	@Override
	public double depositAmount(int accNo, double amount) throws BankingException {
		
		return bankingDao.depositAmount(accNo, amount);
	}

	@Override
	public double getBalance(int accNo) throws BankingException {
		return bankingDao.getBalance(accNo);
	}

	@Override
	public double withdrawAmount(int accNo, double amount) throws BankingException {
		return bankingDao.withdrawAmount(accNo, amount);
	}

	@Override
	public boolean transferAmount(int accNo, int accNo2, double amount) throws BankingException {
		return bankingDao.transferAmount(accNo, accNo2, amount);
	}

	@Override
	public String printTransaction(int accNo) throws BankingException {
		
		return bankingDao.printTransaction(accNo);
	}


}
