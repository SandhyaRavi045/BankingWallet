package com.BankingWallet.servcie;

import com.BankingWallet.bean.Customer;
import com.BankingWallet.exception.BankingException;

public interface BankingService {

	boolean validate(Customer customerRequest) throws BankingException;
	
	boolean login(int accountNumber,String password) throws BankingException;
	public int createAccount(String username, String password) throws BankingException;
	double getBalance(int accNo) throws BankingException;
	double depositAmount(int accNo, double amount) throws BankingException;
	double withdrawAmount(int accNo, double amount) throws BankingException;
	boolean transferAmount(int accNo, int accNo2, double amount) throws BankingException;

	String printTransaction(int accNo) throws BankingException;
	
}
