package org.cap.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDao")
public class AccountDaoImpl implements IAccountDao {
	
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager entityManager;

	@Autowired
	private ILoginService loginService;
	
	@Override
	@Transactional
	public void createAccount(Account account) {
		
		Query query= entityManager.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		
		//System.out.println(account);
		
		entityManager.persist(account);
		
	}

	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAccounts(int customerId) {
		
		Query query= entityManager
			.createQuery("from Account acc where acc.customer.customerId=:custId");
		
		query.setParameter("custId", customerId);
		
		
		List<Account> accounts= query.getResultList();
		
		
		return accounts;
	}
	
	
	
	@Transactional(readOnly=true)
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId){
	
		
		Query query2=entityManager
				.createQuery(strQuery);
		
		query2.setParameter("custId", customerId);
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount))
				);
		return map;
	}

	@Override
	public List<Account> getAllCustomers(Integer customerId) {
		Query query= entityManager
				.createQuery("from Account acc where acc.customer.customerId!=:custId");
			
			query.setParameter("custId", customerId);
			
			
			List<Account> accounts= query.getResultList();
			
			
			return accounts;
	}

	@Override
	public void transferFund(Transaction transaction) {
		
		entityManager.persist(transaction);
		int custId=getCustId(transaction.getToAccount().getAccountId());
		
		Transaction transaction1=new Transaction();
		transaction1.setCustomer(loginService.findCustomer(custId));
		transaction1.setTransactionType("credit");
		transaction1.setFromAccount(transaction.getFromAccount());
		transaction1.setToAccount(transaction.getToAccount());
		transaction1.setAmount(transaction.getAmount());
		transaction1.setDescription(transaction.getDescription());
		transaction1.setStatus(transaction.getStatus());
		transaction1.setTransactionDate(transaction.getTransactionDate());
		
		entityManager.persist(transaction1);
		
		
	}

	private int getCustId(int accountId) {
		
		Query query=entityManager.createQuery("select acc.customer.customerId from Account acc where acc.accountId=:accountId");
		query.setParameter("accountId", accountId);
		
		List<Integer> custId=query.getResultList();
		return custId.get(0);
	}

	@Override
	public Account findAccount(int accountId) {
		
		Query query=entityManager.createQuery("from Account acc where acc.accountId=:accountId");
		query.setParameter("accountId", accountId);
		List<Account> account=query.getResultList();
		return account.get(0);
		
		
	}

	
}
 