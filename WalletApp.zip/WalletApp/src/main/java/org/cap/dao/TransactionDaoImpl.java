package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("transactionDao")
@Transactional
public class TransactionDaoImpl implements ITransactionDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void createAccount(Transaction transaction) {
		
		entityManager.persist(transaction);
		
	}

	@Override
	public List<Transaction> getTransactions(Integer customerId) {
		Query query= entityManager.createQuery("from Transaction transaction where transaction.customer.customerId=:cust");
		query.setParameter("cust", customerId);
			List<Transaction> transaction= query.getResultList();
		for (Transaction trans : transaction) {
			System.out.println(trans);
		}
		
		return transaction;
	}

}
