package org.cap.dao;

import java.util.List;

import org.cap.model.Transaction;

public interface ITransactionDao {
	
	public void createAccount(Transaction transaction);
	public List<Transaction> getTransactions(Integer customerId);


}
