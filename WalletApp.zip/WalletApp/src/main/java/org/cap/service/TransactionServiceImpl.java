package org.cap.service;

import java.util.List;

import org.cap.dao.ITransactionDao;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("transactionService")
public class TransactionServiceImpl implements ITransactionService{
	
	@Autowired
	private ITransactionDao transactionDao;

	@Override
	public void createAccount(Transaction transaction) {
		
		transactionDao.createAccount(transaction);
		
	}

	@Override
	public List<Transaction> getTransactions(Integer customerId) {
		// TODO Auto-generated method stub
		return transactionDao.getTransactions(customerId);
	}

}
