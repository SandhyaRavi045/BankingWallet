package org.cap.service;

import java.util.List;

import org.cap.model.Transaction;

public interface ITransactionService {
	
	public void createAccount(Transaction transaction);

	public List<Transaction> getTransactions(Integer customerId);

}
