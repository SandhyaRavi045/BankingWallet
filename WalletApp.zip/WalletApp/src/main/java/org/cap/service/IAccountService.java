package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface IAccountService {
	public void createAccount(Account account);
	public List<Account> getAllAccounts(int customerId);
	public List<Account> getAccountWithBalance(int custId);
	public List<Account> getAllCustomers(Integer customerId);
	//public List<Transaction> performTransaction(int custId, String transType);
	//List<Transaction> performTransaction(Transaction transaction);
	public void transferFund(Transaction transaction);
	public Account findAccount(int accountId);
	
}
